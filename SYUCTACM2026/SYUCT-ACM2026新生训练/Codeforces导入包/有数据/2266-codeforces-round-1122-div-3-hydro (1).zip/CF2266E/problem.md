## 题目描述

<div><p>给定一个由 $n$ 个正整数组成的 <a href="https://en.wikipedia.org/wiki/Multiset">多重集</a> $a$。</p><p>你可以执行以下操作任意次数（可以为零次）：</p><ul> <li> 从多重集中选择一个整数 $x  \gt  1$ 及 $x$ 的一个质因子 $p$。从多重集中移除一个 $x$ 的出现，并添加 $p$ 个 $\frac{x}{p}$。 </li></ul><p>还给定一个整数 $k$ ($1 \le k \le n$)。令 $f(k)$ 为从原始多重集开始，直到多重集中每个整数都不超过 $k$ 所需的最少操作次数。</p><p>求 $f(k)$。</p></div>

## 输入格式

<p>每个测试包含多个测试用例。第一行包含测试用例的数量 $t$ ($1 \le t \le 10^4$)。随后是各个测试用例的描述。</p><p>每个测试用例的第一行包含两个整数 $n$ 和 $k$ ($1 \le k \le n \le 2 \cdot 10^5$) — 分别为多重集的初始大小和给定整数。</p><p>每个测试用例的第二行包含 $n$ 个整数 $a_1, a_2, \ldots, a_n$ ($1 \le a_i \le n$) — 多重集的元素。</p><p>保证所有测试用例的 $n$ 之和不超过 $2 \cdot 10^5$。</p>

## 输出格式

<p>对于每个测试用例，输出一个整数 $f(k)$。</p>

## 样例

~~~input1
6
1 1
1
6 2
6 6 4 3 2 1
8 1
8 6 4 3 2 1 8 6
12 3
12 10 9 8 7 6 5 4 3 2 1 12
10 9
10 9 8 7 6 5 4 3 2 1
5 5
5 4 3 2 1
~~~

~~~output1
0
4
25
15
1
0
~~~


## 备注

<p>在第一个测试用例中，唯一的元素已经不超过 $k$，因此不需要任何操作。</p><p>在第二个测试用例中，我们可以执行以下操作：</p><p>$[\color{red}{6},6,4,3,2,1] \rightarrow [\color{red}{2,2,2},6,4,3,2,1]$,</p><p>$[2,2,2,\color{red}{6},4,3,2,1] \rightarrow [2,2,2,\color{red}{2,2,2},4,3,2,1]$,</p><p>$[2,2,2,2,2,2,\color{red}{4},3,2,1] \rightarrow [2,2,2,2,2,2,\color{red}{2,2},3,2,1]$,</p><p>$[2,2,2,2,2,2,2,2,\color{red}{3},2,1] \rightarrow [2,2,2,2,2,2,2,2,\color{red}{1,1,1},2,1]$。</p><p>因此，$4$ 次操作足矣。可以证明不存在操作次数严格更少的方案。</p>

## 来源

导入自 [Codeforces](https://codeforces.com/contest/2266/problem/E?locale=en) — Codeforces Round 1122 \(Div. 3\)。


## Source

Imported from [Codeforces](https://codeforces.com/contest/2266/problem/E?locale=en) — Codeforces Round 1122 \(Div. 3\).
