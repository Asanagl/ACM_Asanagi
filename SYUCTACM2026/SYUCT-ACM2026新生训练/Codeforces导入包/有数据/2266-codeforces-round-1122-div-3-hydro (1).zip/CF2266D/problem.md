## Problem Description

<div><p>Vihaan 正在修缮一条由 $n$ 个路段组成的道路。第 $i$ 个路段的高度为 $a_i$。</p><p>他有一辆可以移动路段的叉车。在一次操作中，Vihaan 选择两个下标 $i$ 和 $j$（$1 \le i  \lt j \le n$），将第 $j$ 个路段抬起，并向后移动到位置 $i$。</p><p>当该路段被向后搬运时，每经过一个路段，就有一单位混凝土从上面掉落到该路段上。然后，被搬运的路段插入到位置 $i$。</p><p>更形式化地说，子数组 $$ [a_i,a_{i+1},\ldots,a_{j-1},a_j] $$ 被替换为 $$ [a_j-(j-i),a_i+1,a_{i+1}+1,\ldots,a_{j-1}+1]. $$</p><p>如果道路的一个部分是由高度相等的连续路段组成的，则称该部分为<span>平坦</span>的。</p><p>Vihaan 可以执行任意次数的操作，包括零次。</p><p>求道路平坦部分的最大可能长度。</p></div>

## Input Format

<p>第一行包含一个整数 $t$（$1 \le t \le 10^4$）— 测试用例的数量。</p><p>每个测试用例的第一行包含一个整数 $n$（$1 \le n \le 2 \cdot 10^5$）— 道路的路段数量。</p><p>第二行包含 $n$ 个整数 $a_1,a_2,\ldots,a_n$（${\color{red}n} \le a_i \le 10^9$）— 各路段的初始高度。</p><p>保证所有测试用例的 $n$ 之和不超过 $2 \cdot 10^5$。</p><p>可以证明，在给定的约束条件下，任意操作序列后每个路段的高度始终保持为正。</p>

## Output Format

<p>对于每个测试用例，输出一个整数 — 道路平坦部分的最大可能长度。</p>

## Examples

~~~input1
8
5
5 5 5 9 8
6
6 6 6 6 6 6
5
5 6 7 8 9
5
9 7 12 10 12
4
4 7 5 8
7
14 9 14 12 8 11 12
5
1000000000 1000000000 1000000000 1000000000 1000000000
8
8 8 12 8 14 10 15 13
~~~

~~~output1
4
6
1
5
4
2
5
6
~~~


## Note

<p>在第一个测试用例中，Vihaan 可以将位置 $4$ 的路段移动到位置 $1$：</p><p>$$ [{\color{red}5},{\color{red}5},{\color{red}5},{\color{red}9},8] \rightarrow [{\color{red}6},{\color{red}6},{\color{red}6},{\color{red}6},8]. $$</p><p>因此，可以创建一个长度为 $4$ 的平坦部分。</p><p>在第四个测试用例中，Vihaan 可以执行以下操作：</p><ol> <li> 将位置 $3$ 的路段移动到位置 $1$：<p>$$ [{\color{red}9},{\color{red}7},{\color{red}1}{\color{red}2},10,12] \rightarrow [{\color{red}1}{\color{red}0},{\color{red}1}{\color{red}0},{\color{red}8},10,12]. $$</p></li><li> 将位置 $4$ 的路段移动到位置 $3$：<p>$$ [10,10,{\color{red}8},{\color{red}1}{\color{red}0},12] \rightarrow [10,10,{\color{red}9},{\color{red}9},12]. $$</p></li><li> 将位置 $5$ 的路段移动到位置 $3$：<p>$$ [10,10,{\color{red}9},{\color{red}9},{\color{red}1}{\color{red}2}] \rightarrow [10,10,{\color{red}1}{\color{red}0},{\color{red}1}{\color{red}0},{\color{red}1}{\color{red}0}]. $$</p></li></ol><p>因此，整条道路都可以变为平坦的。</p><p>在第五个测试用例中，Vihaan 可以先将位置 $2$ 的路段移动到位置 $1$：</p><p>$$ [{\color{red}4},{\color{red}7},5,8] \rightarrow [{\color{red}6},{\color{red}5},5,8]. $$</p><p>然后，他可以将位置 $4$ 的路段移动到位置 $2$：</p><p>$$ [6,{\color{red}5},{\color{red}5},{\color{red}8}] \rightarrow [6,{\color{red}6},{\color{red}6},{\color{red}6}]. $$</p><p>因此，整条道路都可以变为平坦的。</p>

## Source

Imported from [Codeforces](https://codeforces.com/contest/2266/problem/D?locale=en) — Codeforces Round 1122 \(Div. 3\).
