## 题目描述

<div><p>给定一个长度为 $n$ 的<span>二进制字符串</span>$^{\text{∗}}$ $s$。</p><p>你可以执行以下操作任意次数（可以为零次）：</p><ul> <li> 选择一个整数 $i$（$1 \le i \le n$），将 $s_i$ 替换为 $s_1, s_2, \ldots, s_i$ 的<a href="https://en.wikipedia.org/wiki/Bitwise_operation#AND">按位 AND</a> 或<a href="https://en.wikipedia.org/wiki/Bitwise_operation#OR">按位 OR</a>。</li></ul><p>注意，单个元素的按位 AND 或按位 OR 等于该元素本身。</p><p>你的目标是使 $s$ 按非降序排列$^{\text{†}}$。</p><p>求使 $s$ 按非降序排列所需的最少操作次数。</p><div><p>$^{\text{∗}}$二进制字符串仅包含字符 $\texttt{0}$ 和 $\texttt{1}$。</p><p>$^{\text{†}}$如果 $s$ 按非降序排列，则 $s_1 \leq s_2 \leq \ldots \leq s_n$。</p></div></div>

## 输入格式

<p>第一行包含一个整数 $t$（$1 \le t \le 10^4$）— 测试用例的数量。</p><p>每个测试用例的第一行包含一个整数 $n$（$2 \le n \le 2 \cdot 10^5$）— 二进制字符串 $s$ 的长度。</p><p>每个测试用例的第二行包含长度为 $n$ 的二进制字符串 $s$。$s$ 的每个字符要么是 <span>0</span> 要么是 <span>1</span>。</p><p>保证所有测试用例的 $n$ 之和不超过 $2 \cdot 10^5$。</p>

## 输出格式

<p>对于每个测试用例，输出一个整数 — 使 $s$ 按非降序排列所需的最少操作次数。</p>

## 样例

~~~input1
6
4
0011
4
1000
5
01000
8
01001101
7
0101010
7
0111101
~~~

~~~output1
0
3
1
2
3
1
~~~


## 注意

<p>在第一个测试用例中，字符串已经有序，因此不需要任何操作。</p><p>在第二个测试用例中，我们可以使用按位 OR 将最后三个字符变为 <span>1</span>，在 $3$ 次操作中得到 <span>1111</span>。</p>

## 来源

导入自 [Codeforces](https://codeforces.com/contest/2266/problem/C?locale=en) — Codeforces Round 1122 \(Div. 3\)。


## Source

Imported from [Codeforces](https://codeforces.com/contest/2266/problem/C?locale=en) — Codeforces Round 1122 \(Div. 3\).
