// CF2272A testlib checker (multi-answer SPJ).
// Verdict OK iff participant's answer achieves the optimal k-th-largest f value.
// Usage (Hydro testlib): chk <input> <user_output> <answer>
//   argv[1]=input, argv[2]=participant output, argv[3]=jury answer (ignored).
#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

static vector<int> computeF(const vector<int>& a) {
    int n = (int)a.size();
    vector<int> f(n);
    vector<char> seen(n + 2, 0);
    int mex = 0;
    for (int i = 0; i < n; i++) {
        seen[a[i]] = 1;
        while (seen[mex]) mex++;
        f[i] = mex;
    }
    return f;
}

static int kthLargest(const vector<int>& f, int k) {
    vector<int> g = f;
    sort(g.begin(), g.end(), greater<int>());
    return g[k - 1];
}

// Brute optimal: try no-swap + all O(n^2) swaps. n<=100, sum n<=100.
static int optimalValue(int n, int k, const vector<int>& a) {
    int best = kthLargest(computeF(a), k);
    vector<int> b(n);
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            b = a;
            swap(b[i], b[j]);
            best = max(best, kthLargest(computeF(b), k));
        }
    return best;
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    int t = inf.readInt(1, 50, "t");
    for (int ci = 0; ci < t; ci++) {
        int n = inf.readInt(2, 100, "n");
        int k = inf.readInt(1, n, "k");
        vector<int> a(n);
        for (int i = 0; i < n; i++)
            a[i] = inf.readInt(0, n - 1, "a_i");

        // Participant answer: either "-1" or "i j" (1-indexed, i != j).
        // Read first integer; -1 means no swap, otherwise it is index i.
        long long v = ouf.readLong();
        int value;
        if (v == -1) {
            value = kthLargest(computeF(a), k);
        } else {
            int i = (int)v;
            if (i < 1 || i > n)
                quitf(_wa, "case %d: first index %d out of [1,%d]", ci + 1, i, n);
            long long j = ouf.readLong();
            if (j < 1 || j > n)
                quitf(_wa, "case %d: second index %lld out of [1,%d]", ci + 1, j, n);
            if (i == (int)j)
                quitf(_wa, "case %d: indices equal (%d)", ci + 1, i);
            vector<int> b = a;
            swap(b[i - 1], b[(int)j - 1]);
            value = kthLargest(computeF(b), k);
        }

        int opt = optimalValue(n, k, a);
        if (value != opt)
            quitf(_wa, "case %d: k-th largest value %d is not optimal (optimal %d)",
                  ci + 1, value, opt);
    }
    quitf(_ok, "all %d cases achieve the optimal k-th largest value", t);
}
