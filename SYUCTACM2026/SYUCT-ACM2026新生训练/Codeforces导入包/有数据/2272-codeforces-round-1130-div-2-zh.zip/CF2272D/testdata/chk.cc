// CF2272D testlib checker (multi-answer SPJ).
// Verdict OK iff the participant's added edges merge the forest into a single tree
// whose maximum independent set equals the theoretical optimum
//   OPT = sum_i MIS(T_i) - (1 if all trees are single-vertex else 0).
// Usage (Hydro testlib): chk <input> <user_output> <answer>
//   argv[1]=input, argv[2]=participant output, argv[3]=jury answer (ignored).
#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

struct DSU {
    vector<int> p;
    explicit DSU(int n) : p(n) { iota(p.begin(), p.end(), 0); }
    int f(int x) { while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; } return x; }
    bool unite(int a, int b) { a = f(a); b = f(b); if (a == b) return false; p[a] = b; return true; }
};

// Maximum independent set of a tree given as edge list on N vertices (0-indexed).
static int misTree(int N, const vector<pair<int,int>>& edges) {
    if (N <= 0) return 0;
    if (N == 1) return 1;
    vector<vector<int>> adj(N);
    for (auto& e : edges) { adj[e.first].push_back(e.second); adj[e.second].push_back(e.first); }
    vector<int> par(N, -1), order; order.reserve(N);
    vector<char> vis(N, 0); vis[0] = 1;
    vector<int> stk; stk.reserve(N); stk.push_back(0);
    while (!stk.empty()) {
        int v = stk.back(); stk.pop_back(); order.push_back(v);
        for (int w : adj[v]) if (!vis[w]) { vis[w] = 1; par[w] = v; stk.push_back(w); }
    }
    vector<int> dp0(N, 0), dp1(N, 1);
    for (int i = N - 1; i >= 1; i--) {
        int v = order[i], p = par[v];
        dp0[p] += max(dp0[v], dp1[v]);
        dp1[p] += dp0[v];
    }
    return max(dp0[0], dp1[0]);
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    int t = inf.readInt(1, 10000, "t");
    for (int ci = 0; ci < t; ci++) {
        int k = inf.readInt(2, 200000, "k");
        vector<int> ns(k);
        vector<vector<pair<int,int>>> trees(k);
        int N = 0;
        bool allSingle = true;
        int opt = 0;
        for (int i = 0; i < k; i++) {
            int n = inf.readInt(1, 200000, "n");
            ns[i] = n;
            N += n;
            vector<pair<int,int>> es;
            for (int e = 0; e < n - 1; e++) {
                int u = inf.readInt(1, n, "u");
                int v = inf.readInt(1, n, "v");
                if (u == v)
                    quitf(_fail, "case %d tree %d: self-edge in input", ci + 1, i + 1);
                es.push_back({u - 1, v - 1});
            }
            trees[i] = es;
            if (n > 1) { allSingle = false; opt += misTree(n, es); }
            else opt += 1;
        }
        if (allSingle) opt -= 1;

        vector<int> off(k + 1, 0);
        for (int i = 0; i < k; i++) off[i + 1] = off[i] + ns[i];

        vector<pair<int,int>> gtree;
        DSU dsu(N);
        for (int i = 0; i < k; i++) {
            for (auto& e : trees[i]) {
                int a = off[i] + e.first, b = off[i] + e.second;
                if (!dsu.unite(a, b))
                    quitf(_fail, "case %d tree %d: input not a tree (cycle)", ci + 1, i + 1);
                gtree.push_back({a, b});
            }
        }

        for (int li = 0; li < k - 1; li++) {
            long long t1 = ouf.readLong();
            long long v1 = ouf.readLong();
            long long t2 = ouf.readLong();
            long long v2 = ouf.readLong();
            if (t1 < 1 || t1 > k)
                quitf(_wa, "case %d line %d: t1=%lld out of [1,%d]", ci + 1, li + 1, t1, k);
            if (t2 < 1 || t2 > k)
                quitf(_wa, "case %d line %d: t2=%lld out of [1,%d]", ci + 1, li + 1, t2, k);
            if (v1 < 1 || v1 > ns[t1 - 1])
                quitf(_wa, "case %d line %d: v1=%lld out of [1,%d]", ci + 1, li + 1, v1, ns[t1 - 1]);
            if (v2 < 1 || v2 > ns[t2 - 1])
                quitf(_wa, "case %d line %d: v2=%lld out of [1,%d]", ci + 1, li + 1, v2, ns[t2 - 1]);
            int a = off[t1 - 1] + (int)v1 - 1;
            int b = off[t2 - 1] + (int)v2 - 1;
            if (a == b)
                quitf(_wa, "case %d line %d: self-loop (same global vertex)", ci + 1, li + 1);
            if (!dsu.unite(a, b))
                quitf(_wa, "case %d line %d: edge creates a cycle; merged graph is not a tree", ci + 1, li + 1);
            gtree.push_back({a, b});
        }

        // N vertices, (N - k) original + (k - 1) added = N - 1 edges, acyclic => connected tree.
        int val = misTree(N, gtree);
        if (val != opt)
            quitf(_wa, "case %d: merged tree MIS = %d, optimal = %d", ci + 1, val, opt);
    }
    quitf(_ok, "all %d cases: merged tree is a tree and MIS is optimal", t);
}
