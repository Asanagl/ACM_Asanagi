## Problem Description

<div><p>You are given a <span>binary string</span>$^{\text{∗}}$ $s$ of length $n$.</p><p>You may perform the following operation any number of times (possibly zero):</p><ul> <li> choose an integer $i$ ($1 \le i \le n$), and replace $s_i$ with either the <a href="https://en.wikipedia.org/wiki/Bitwise_operation#AND">bitwise AND</a> or the <a href="https://en.wikipedia.org/wiki/Bitwise_operation#OR">bitwise OR</a> of $s_1, s_2, \ldots, s_i$. </li></ul><p>Note that the bitwise AND or bitwise OR of a single element is equal to the element itself.</p><p>Your goal is to make $s$ sorted in non-decreasing order$^{\text{†}}$.</p><p>Find the minimum number of operations required to sort $s$ in non-decreasing order.</p><div><p>$^{\text{∗}}$A binary string only contains characters $\texttt{0}$ and $\texttt{1}$.</p><p>$^{\text{†}}$If $s$ is in non-decreasing order, then $s_1 \leq s_2 \leq \ldots \leq s_n$.</p></div></div>

## Input Format

<p>The first line contains a single integer $t$ ($1 \le t \le 10^4$) — the number of test cases.</p><p>The first line of each test case contains a single integer $n$ ($2 \le n \le 2 \cdot 10^5$) — the length of the binary string $s$.</p><p>The second line of each test case contains the binary string $s$ of length $n$. Each character of $s$ is either <span>0</span> or <span>1</span>.</p><p>It is guaranteed that the sum of $n$ over all test cases does not exceed $2 \cdot 10^5$.</p>

## Output Format

<p>For each test case, print a single integer — the minimum number of operations required to sort $s$ in non-decreasing order.</p>

## Examples

~~~input1
6
4
0011
4
1000
5
01000
8
01001101
7
0101010
7
0111101
~~~

~~~output1
0
3
1
2
3
1
~~~


## Note

<p>In the first test case, the string is already sorted, so no operations are required.</p><p>In the second test case, we can use bitwise OR to change the last three characters to <span>1</span>, obtaining <span>1111</span> in $3$ operations.</p>

## Source

Imported from [Codeforces](https://codeforces.com/contest/2266/problem/C?locale=en) — Codeforces Round 1122 \(Div. 3\).
